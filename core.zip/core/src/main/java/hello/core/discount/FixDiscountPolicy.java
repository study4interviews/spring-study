package hello.core.discount;

import hello.core.member.Member;

public class FixDiscountPolicy implements DiscountPolicy {
    private final int AMOUNT = 1000;
    @Override
    public int discount(Member member, int price) {
        switch (member.getGrade()) {
            case VIP:
                return AMOUNT;
            case BASIC:
                return 0;
        }
        return 0;
    }
}
