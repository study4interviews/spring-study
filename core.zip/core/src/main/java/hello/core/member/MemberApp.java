package hello.core.member;

import hello.core.AppConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MemberApp {

    public static void main(String[] args) {
//

        AppConfig config = new AppConfig();
        MemberService service = config.memberService();


        ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);

        MemberService memberService = ctx.getBean("memberService", MemberService.class);

//        MemberService service = new MemberServiceImpl();
//
//
        Member memberA = new Member(1L, "memberA", Grade.BASIC);
        service.join(memberA);

        Member number = service.findNumber(1L);
        System.out.println("number = " + number.getName());
        System.out.println("memberA = " + memberA.getName());

    }
}
